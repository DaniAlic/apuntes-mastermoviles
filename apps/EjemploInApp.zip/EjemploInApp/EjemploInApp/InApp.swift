//
//  InApp.swift
//  EjemploInApp
//
//  Created by Domingo on 17/5/16.
//  Copyright © 2016 Master móviles. All rights reserved.
//

import Foundation
import StoreKit

protocol InAppDelegate {
    func compraRecibida()
}

class InApp: NSObject, SKProductsRequestDelegate, SKPaymentTransactionObserver {
    var productDetailsList: [SKProduct] = []
    var productIdentiferList: [String] = []
    var delegate: InAppDelegate?
    
    override init() {
        super.init()
        SKPaymentQueue.default().add(self)

        // Cargamos la lista de productos
        
        productIdentiferList.append("ejemplo3")
        let request = SKProductsRequest.init(productIdentifiers: Set(productIdentiferList))
        request.delegate = self
        request.start()
    }
    
    func lanzarPago() {
        if (self.productDetailsList.count > 0 &&  SKPaymentQueue.canMakePayments()) {
            let producto = productDetailsList[0]
            let pago = SKPayment(product: producto)
            SKPaymentQueue.default().add(pago)
            print("Comprando...")
        } else {
            print("No existen productos")
        }
    }
    
    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
        for transaction in transactions {
            switch transaction.transactionState {
            case .purchased:
                print("Purchased")
                delegate?.compraRecibida()
                SKPaymentQueue.default().finishTransaction(transaction)
            case .failed:
                print("Failed")
                print("Error de transacción: \(String(describing: transaction.error?.localizedDescription))")
                SKPaymentQueue.default().finishTransaction(transaction)
            case .restored:
                print("Restored")
                delegate?.compraRecibida()
                SKPaymentQueue.default().finishTransaction(transaction)
            default:
                print("Otro")
            }
        }
    }
    
    func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
        print("Hemos recibido \(response.products.count) productos")
        productDetailsList = response.products
        for invalidProductId in response.invalidProductIdentifiers {
            print("Producto invalido id: \(invalidProductId)")
        }
    }
}
