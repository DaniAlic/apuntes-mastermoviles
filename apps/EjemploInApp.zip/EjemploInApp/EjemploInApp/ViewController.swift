//
//  ViewController.swift
//  EjemploInApp
//
//  Created by Domingo on 11/5/16.
//  Copyright © 2016 Master móviles. All rights reserved.
//

import UIKit

class ViewController: UIViewController, InAppDelegate {

    @IBOutlet weak var botonSorpresa: UIButton!
    let inApp = InApp()

    override func viewDidLoad() {
        
        inApp.delegate = self
        
        botonSorpresa.isHidden = true
    
        // Comprobamos si hemos comprado antes el inApp
        
        if UserDefaults.standard.bool(forKey: "inAppComprado") {
            botonSorpresa.isHidden = false
        } else {
            botonSorpresa.isHidden = true
        }

        // Reinicia cualquier transacción si esta se interrumpió
        
        super.viewDidLoad()
    }
    
    func compraRecibida() {
        botonSorpresa.isHidden = false
    }
    
    
    @IBAction func hazCompra(_ sender: UIButton) {
        print("Click botón de compra")
        inApp.lanzarPago()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func sorpresa(_ sender: UIButton){
        performSegue(withIdentifier: "Sorpresa", sender: view)
    }
}
