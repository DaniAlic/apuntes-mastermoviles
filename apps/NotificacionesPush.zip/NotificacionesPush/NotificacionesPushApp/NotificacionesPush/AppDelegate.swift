

import UIKit


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        UITabBar.appearance().barTintColor = UIColor.themeGreenColor
        UITabBar.appearance().tintColor = UIColor.white
        registerForPushNotifications(application)
        if let notification = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification]
            as? [String: AnyObject] {
            let aps = notification["aps"] as! [String: AnyObject]
            createNewNewsItem(aps)
            (window?.rootViewController as? UITabBarController)?.selectedIndex = 1
        }
        return true
    }

    // MARK: Helpers
    func createNewNewsItem(_ notificationDictionary:[String: AnyObject]) {
        if let news = notificationDictionary["alert"] as? String {
            let date = Date()
            
            let newsItem = NewsItem(title: news, date: date)
            let newsStore = NewsStore.sharedStore
            newsStore.addItem(newsItem)
            
            NotificationCenter.default.post(name: Notification.Name(rawValue: NewsFeedTableViewController.RefreshNewsFeedNotification), object: self)
        }
    }
    
    func registerForPushNotifications(_ application: UIApplication) {
        let notificationSettings = UIUserNotificationSettings(
            types: [.badge, .sound, .alert],
            categories: nil)
        application.registerUserNotificationSettings(notificationSettings)
    }
    
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        if notificationSettings.types != .none {
            application.registerForRemoteNotifications()
        }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        var token = ""
        for i in 0..<deviceToken.count {
            token = token + String(format: "%02.2hhx", arguments: [deviceToken[i]])
        }
        print(token)
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Failed to register:", error)
    }

    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        let aps = userInfo["aps"] as! [String: AnyObject]
        createNewNewsItem(aps)
    }

}

